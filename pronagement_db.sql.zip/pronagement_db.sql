-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 26, 2024 at 04:44 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pronagement_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth`
--

CREATE TABLE `eg_auth` (
  `id` int(5) NOT NULL,
  `username` varchar(15) COLLATE utf8_swedish_ci NOT NULL,
  `syspassword` longtext CHARACTER SET latin1 NOT NULL,
  `usertype` varchar(255) COLLATE utf8_swedish_ci NOT NULL DEFAULT 'FALSE',
  `name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `division` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `accessgrant` varchar(25) COLLATE utf8_swedish_ci NOT NULL DEFAULT 'all',
  `lastlogin` varchar(25) COLLATE utf8_swedish_ci DEFAULT NULL,
  `online` varchar(3) COLLATE utf8_swedish_ci NOT NULL DEFAULT 'OFF',
  `num_attempt` int(5) NOT NULL DEFAULT 0,
  `input_count` int(11) NOT NULL DEFAULT 0,
  `timestamp_count` varchar(25) COLLATE utf8_swedish_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_dept`
--

CREATE TABLE `eg_dept` (
  `38id` int(4) NOT NULL,
  `38title` varchar(255) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_item`
--

CREATE TABLE `eg_item` (
  `id` int(11) NOT NULL,
  `eg_tier1_id` int(11) NOT NULL,
  `eg_tier2_id` int(11) NOT NULL,
  `eg_dept_id` int(11) NOT NULL,
  `38field4` varchar(150) COLLATE utf8_swedish_ci NOT NULL,
  `38field5` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `38field6` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `39inputdate` varchar(25) COLLATE utf8_swedish_ci NOT NULL,
  `39inputby` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `40lastupdateby` varchar(50) COLLATE utf8_swedish_ci DEFAULT NULL,
  `41instimestamp` varchar(12) COLLATE utf8_swedish_ci DEFAULT NULL,
  `50search_cloud` mediumtext COLLATE utf8_swedish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_tier1`
--

CREATE TABLE `eg_tier1` (
  `38id` int(4) NOT NULL,
  `38title` text COLLATE utf8_swedish_ci NOT NULL,
  `38desc` text COLLATE utf8_swedish_ci NOT NULL,
  `38participant` text COLLATE utf8_swedish_ci NOT NULL,
  `38datestart` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `38dateend` varchar(255) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_tier2`
--

CREATE TABLE `eg_tier2` (
  `38id` int(4) NOT NULL,
  `eg_tier1_id` int(11) NOT NULL,
  `38title` text COLLATE utf8_swedish_ci NOT NULL,
  `38desc` text COLLATE utf8_swedish_ci NOT NULL,
  `38tasktype` varchar(25) COLLATE utf8_swedish_ci NOT NULL DEFAULT 'targetsetting',
  `38datestart` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `38dateend` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `38target` decimal(20,6) NOT NULL,
  `38targetunit` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `39cur_achv` double(20,6) NOT NULL DEFAULT 0.000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_tier3`
--

CREATE TABLE `eg_tier3` (
  `38id` int(4) NOT NULL,
  `eg_tier1_id` int(11) NOT NULL,
  `eg_tier2_id` int(11) NOT NULL,
  `eg_dept_id` int(11) NOT NULL,
  `38target` double(20,6) NOT NULL,
  `38targetstatement` text COLLATE utf8_swedish_ci NOT NULL,
  `38accesskey` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `39achv` double(20,6) NOT NULL DEFAULT 0.000000,
  `39achv_timestamp` varchar(255) COLLATE utf8_swedish_ci NOT NULL DEFAULT '1577836800'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog`
--

CREATE TABLE `eg_userlog` (
  `id` int(11) NOT NULL,
  `37keyword` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `37type` varchar(20) COLLATE utf8_swedish_ci NOT NULL DEFAULT 'All Type',
  `37freq` int(11) NOT NULL,
  `37lastlog` varchar(25) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eg_auth`
--
ALTER TABLE `eg_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_dept`
--
ALTER TABLE `eg_dept`
  ADD PRIMARY KEY (`38id`),
  ADD KEY `38typeid` (`38id`);

--
-- Indexes for table `eg_item`
--
ALTER TABLE `eg_item`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `40lastupdateby` (`40lastupdateby`),
  ADD KEY `39inputby` (`39inputby`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38title` (`38field5`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `38author` (`38field4`);
ALTER TABLE `eg_item` ADD FULLTEXT KEY `50search_cloud` (`50search_cloud`);

--
-- Indexes for table `eg_tier1`
--
ALTER TABLE `eg_tier1`
  ADD PRIMARY KEY (`38id`),
  ADD KEY `38typeid` (`38id`);

--
-- Indexes for table `eg_tier2`
--
ALTER TABLE `eg_tier2`
  ADD PRIMARY KEY (`38id`),
  ADD KEY `38typeid` (`38id`);

--
-- Indexes for table `eg_tier3`
--
ALTER TABLE `eg_tier3`
  ADD PRIMARY KEY (`38id`),
  ADD KEY `38typeid` (`38id`);

--
-- Indexes for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eg_auth`
--
ALTER TABLE `eg_auth`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_dept`
--
ALTER TABLE `eg_dept`
  MODIFY `38id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_item`
--
ALTER TABLE `eg_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_tier1`
--
ALTER TABLE `eg_tier1`
  MODIFY `38id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_tier2`
--
ALTER TABLE `eg_tier2`
  MODIFY `38id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_tier3`
--
ALTER TABLE `eg_tier3`
  MODIFY `38id` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
